// Ghadeer wrote this
var background = document.getElementById('pressplusOverlay'),
	modal = document.getElementById('ppUI');
	
	background.style.display = "none";
	modal.style.display = "none";